:- use_module(library(http/thread_httpd)).
:- use_module(library(http/http_dispatch)).
:- use_module(library(http/http_json)).

:- http_handler('/analizar', handle_analizar, [method(post)]).
:- http_handler('/health', handle_health, [method(get)]).

handle_health(_) :-
    reply_json_dict(_{status: ok}).

handle_analizar(_Request) :-
    reply_json_dict(_{status: ok, message: "Voyager funcionando"}).

main :-
    http_server(http_dispatch, [port(8001)]),
    thread_get_message(_).

:- initialization(main, main).
