% ============================================================
% VOYAGER IX — Sistema Experto con Datos Dinamicos (Prolog)
% Paradigmas del Lenguaje 2026-01
% Genera observaciones aleatorias y las clasifica con reglas
% ============================================================

:- use_module(library(http/thread_httpd)).
:- use_module(library(http/http_dispatch)).
:- use_module(library(http/http_json)).
:- use_module(library(http/http_client)).
:- use_module(library(http/http_parameters)).
:- use_module(library(random)).
:- use_module(library(lists)).

% -----------------------------------------------------------
% BASE DE CONOCIMIENTO: Reglas de clasificacion
% -----------------------------------------------------------

formacion_natural(X) :- simetria(X, baja), rugosidad(X, alta).
formacion_natural(X) :- simetria(X, media), material(X, silicato), temperatura(X, extrema).
formacion_natural(X) :- actividad_volcanica(X, activa).
formacion_natural(X) :- patron_fractal(X, confirmado).
formacion_natural(X) :- erosion_detectable(X, si), geometria(X, irregular).

interferencia_sensor(X) :- duracion(X, transitoria), repeticion(X, aleatoria).
interferencia_sensor(X) :- radiacion_cosmica(X, alta), duracion(X, transitoria).
interferencia_sensor(X) :- temperatura_sensor(X, anormal).
interferencia_sensor(X) :- patron_interferencia(X, si).

anomalia_no_natural(X) :-
    simetria(X, perfecta),
    \+ formacion_natural(X),
    \+ interferencia_sensor(X),
    material(X, desconocido).
anomalia_no_natural(X) :-
    simetria(X, alta),
    geometria(X, regular),
    \+ formacion_natural(X),
    \+ interferencia_sensor(X),
    repeticion(X, periodica).
anomalia_no_natural(X) :-
    \+ formacion_natural(X),
    \+ interferencia_sensor(X),
    geometria(X, regular),
    material(X, metalico).

% -----------------------------------------------------------
% GENERADOR DE OBSERVACIONES ALEATORIAS
% -----------------------------------------------------------

:- dynamic simetria/2, rugosidad/2, material/2, temperatura/2,
           actividad_volcanica/2, patron_fractal/2, erosion_detectable/2,
           geometria/2, duracion/2, repeticion/2, radiacion_cosmica/2,
           temperatura_sensor/2, patron_interferencia/2.

pick_random(List, Val) :-
    length(List, Len),
    random_between(1, Len, Idx),
    nth1(Idx, List, Val).

generar_observacion(Id) :-
    retractall(simetria(Id, _)),
    retractall(rugosidad(Id, _)),
    retractall(material(Id, _)),
    retractall(temperatura(Id, _)),
    retractall(actividad_volcanica(Id, _)),
    retractall(patron_fractal(Id, _)),
    retractall(erosion_detectable(Id, _)),
    retractall(geometria(Id, _)),
    retractall(duracion(Id, _)),
    retractall(repeticion(Id, _)),
    retractall(radiacion_cosmica(Id, _)),
    retractall(temperatura_sensor(Id, _)),
    retractall(patron_interferencia(Id, _)),
    pick_random([perfecta,alta,media,baja], V1),  assertz(simetria(Id, V1)),
    pick_random([alta,baja,media], V2),           assertz(rugosidad(Id, V2)),
    pick_random([desconocido,silicato,metalico,organico], V3), assertz(material(Id, V3)),
    pick_random([extrema,moderada,baja], V4),     assertz(temperatura(Id, V4)),
    pick_random([activa,inactiva], V5),           assertz(actividad_volcanica(Id, V5)),
    pick_random([confirmado,no_confirmado], V6),  assertz(patron_fractal(Id, V6)),
    pick_random([si,no], V7),                     assertz(erosion_detectable(Id, V7)),
    pick_random([regular,irregular], V8),         assertz(geometria(Id, V8)),
    pick_random([persistente,transitoria], V9),   assertz(duracion(Id, V9)),
    pick_random([periodica,aleatoria], V10),      assertz(repeticion(Id, V10)),
    pick_random([alta,normal], V11),              assertz(radiacion_cosmica(Id, V11)),
    pick_random([anormal,normal], V12),           assertz(temperatura_sensor(Id, V12)),
    pick_random([si,no], V13),                    assertz(patron_interferencia(Id, V13)).

gen_ra(RA) :-
    random_between(0, 23, H),
    random_between(0, 59, M),
    format(atom(RA), '~wh~wm', [H, M]).

gen_dec(Dec) :-
    random_between(-89, 89, D),
    random_between(0, 59, M),
    format(atom(Dec), '~w_~w', [D, M]).

gen_espectral(Esp) :-
    random_between(65, 90, C1), char_code(A1, C1),
    random_between(1, 9, N1),
    random_between(65, 90, C2), char_code(A2, C2),
    random_between(1, 9, N2),
    random_between(65, 90, C3), char_code(A3, C3),
    random_between(1, 9, N3),
    format(atom(Esp), '~w~w-~w~w-~w~w', [A1,N1,A2,N2,A3,N3]).

gen_anomalia_id(Id) :-
    random_between(1000, 9999, N),
    format(atom(Id), 'KPL442B-~w', [N]).

% -----------------------------------------------------------
% CLASIFICACION E INFERENCIA
% -----------------------------------------------------------

clasificar(Anomalia, Clasificacion, Confianza) :-
    (anomalia_no_natural(Anomalia) ->
        Clasificacion = 'ANOMALIA_NO_NATURAL',
        calcular_confianza(Anomalia, Confianza)
    ;
        (formacion_natural(Anomalia) ->
            Clasificacion = 'FORMACION_NATURAL',
            Confianza = 0.85
        ;
            (interferencia_sensor(Anomalia) ->
                Clasificacion = 'INTERFERENCIA_SENSOR',
                Confianza = 0.70
            ;
                Clasificacion = 'INDETERMINADO',
                Confianza = 0.30
            )
        )
    ).

calcular_confianza(X, Confianza) :-
    findall(1, regla_aplicada(X, _), Rs),
    length(Rs, N),
    Confianza is min(0.99, 0.65 + N * 0.07).

regla_aplicada(X, 'regla_geologia_01') :- simetria(X, perfecta).
regla_aplicada(X, 'regla_geologia_02') :- \+ formacion_natural(X).
regla_aplicada(X, 'regla_sensor_03')   :- \+ interferencia_sensor(X).
regla_aplicada(X, 'regla_geologia_04') :- geometria(X, regular).
regla_aplicada(X, 'regla_sensor_05')   :- repeticion(X, periodica).
regla_aplicada(X, 'regla_clasificacion_06') :- material(X, desconocido).
regla_aplicada(X, 'regla_clasificacion_07') :- material(X, metalico).

% -----------------------------------------------------------
% HTTP HANDLERS
% -----------------------------------------------------------

:- http_handler('/analizar',        handle_analizar,        [method(post), chunked]).
:- http_handler('/analizar-manual', handle_analizar_manual, [method(post), chunked]).
:- http_handler('/health',          handle_health,          [method(get)]).
:- http_handler('/historial',       handle_historial,       [method(get)]).
:- http_handler('/consulta',        handle_consulta,        [method(get)]).

handle_health(_) :-
    reply_json_dict(_{
        status: "ok", nodo: "VOYAGER_IX", lenguaje: "Prolog",
        descripcion: "Sistema experto con datos dinamicos"
    }).

% Lee y descarta el body para evitar error "Illegal HTTP parameter"
handle_analizar(Request) :-
    % Leer body completo y descartarlo — no lo necesitamos
    ( http_read_data(Request, _, [to(atom)]) -> true ; true ),
    gen_anomalia_id(AnomaliaId),
    generar_observacion(AnomaliaId),
    clasificar(AnomaliaId, Clasificacion, Confianza),
    findall(R, regla_aplicada(AnomaliaId, R), Reglas),
    gen_ra(RA), gen_dec(Dec), gen_espectral(Espectral),
    get_time(T),
    format_time(atom(TS), '%Y-%m-%dT%H:%M:%SZ', T),
    Reporte = _{
        mission_id:    "VOYAGER-IX-2041",
        anomalia_id:   AnomaliaId,
        coordenadas: _{ascension_recta: RA, declinacion: Dec},
        lectura_espectral: _{
            codigo: Espectral, banda_visible: "0.45-0.75um",
            banda_infrarroja: "1.2-2.5um", albedo: 0.34, temperatura_k: "284K"
        },
        clasificacion: Clasificacion,
        confianza:     Confianza,
        cadena_reglas: Reglas,
        timestamp_utc: TS,
        origen:        "VOYAGER_IX"
    },
    format("~n[VOYAGER] Anomalia: ~w | ~w | confianza: ~4f~n",
           [AnomaliaId, Clasificacion, Confianza]),
    % Envio AUTOMATICO a HERMES
    catch(
        (http_post('http://hermes:8002/relay', json(Reporte), _, [timeout(10)]),
         format("[VOYAGER] -> Enviado automaticamente a HERMES~n")),
        Err,
        format("[VOYAGER] Advertencia HERMES: ~w~n", [Err])
    ),
    reply_json_dict(Reporte).


% -----------------------------------------------------------
% HANDLER MANUAL — recibe atributos del usuario
% -----------------------------------------------------------
handle_analizar_manual(Request) :-
    http_read_json_dict(Request, Body),
    gen_anomalia_id(AnomaliaId),
    % Limpiar hechos anteriores
    retractall(simetria(AnomaliaId, _)),
    retractall(rugosidad(AnomaliaId, _)),
    retractall(material(AnomaliaId, _)),
    retractall(temperatura(AnomaliaId, _)),
    retractall(actividad_volcanica(AnomaliaId, _)),
    retractall(patron_fractal(AnomaliaId, _)),
    retractall(erosion_detectable(AnomaliaId, _)),
    retractall(geometria(AnomaliaId, _)),
    retractall(duracion(AnomaliaId, _)),
    retractall(repeticion(AnomaliaId, _)),
    retractall(radiacion_cosmica(AnomaliaId, _)),
    retractall(temperatura_sensor(AnomaliaId, _)),
    retractall(patron_interferencia(AnomaliaId, _)),
    % Cargar datos del body
    atom_string(V1,  Body.simetria),            assertz(simetria(AnomaliaId, V1)),
    atom_string(V2,  Body.rugosidad),           assertz(rugosidad(AnomaliaId, V2)),
    atom_string(V3,  Body.material),            assertz(material(AnomaliaId, V3)),
    atom_string(V4,  Body.temperatura),         assertz(temperatura(AnomaliaId, V4)),
    atom_string(V5,  Body.actividad_volcanica), assertz(actividad_volcanica(AnomaliaId, V5)),
    atom_string(V6,  Body.patron_fractal),      assertz(patron_fractal(AnomaliaId, V6)),
    atom_string(V7,  Body.erosion_detectable),  assertz(erosion_detectable(AnomaliaId, V7)),
    atom_string(V8,  Body.geometria),           assertz(geometria(AnomaliaId, V8)),
    atom_string(V9,  Body.duracion),            assertz(duracion(AnomaliaId, V9)),
    atom_string(V10, Body.repeticion),          assertz(repeticion(AnomaliaId, V10)),
    atom_string(V11, Body.radiacion_cosmica),   assertz(radiacion_cosmica(AnomaliaId, V11)),
    atom_string(V12, Body.temperatura_sensor),  assertz(temperatura_sensor(AnomaliaId, V12)),
    atom_string(V13, Body.patron_interferencia),assertz(patron_interferencia(AnomaliaId, V13)),
    % Clasificar con las reglas
    clasificar(AnomaliaId, Clasificacion, Confianza),
    findall(R, regla_aplicada(AnomaliaId, R), Reglas),
    gen_ra(RA), gen_dec(Dec), gen_espectral(Espectral),
    get_time(T),
    format_time(atom(TS), '%Y-%m-%dT%H:%M:%SZ', T),
    Reporte = _{
        mission_id:    "VOYAGER-IX-2041",
        anomalia_id:   AnomaliaId,
        modo:          "MANUAL",
        coordenadas:   _{ascension_recta: RA, declinacion: Dec},
        lectura_espectral: _{
            codigo: Espectral, banda_visible: "0.45-0.75um",
            banda_infrarroja: "1.2-2.5um", albedo: 0.34, temperatura_k: "284K"
        },
        clasificacion: Clasificacion,
        confianza:     Confianza,
        cadena_reglas: Reglas,
        timestamp_utc: TS,
        origen:        "VOYAGER_IX"
    },
    format("~n[VOYAGER-MANUAL] Anomalia: ~w | ~w | confianza: ~4f~n",
           [AnomaliaId, Clasificacion, Confianza]),
    catch(
        (http_post('http://hermes:8002/relay', json(Reporte), _, [timeout(10)]),
         format("[VOYAGER-MANUAL] -> Enviado a HERMES~n")),
        Err,
        format("[VOYAGER-MANUAL] Advertencia HERMES: ~w~n", [Err])
    ),
    reply_json_dict(Reporte).

handle_historial(_) :-
    reply_json_dict(_{
        mission: "VOYAGER-IX-2041",
        estado_sonda: "OPERACIONAL",
        distancia_km: 1200000000,
        historial: [
            _{fecha:"2038-03-15", evento:"Calibracion de sensores"},
            _{fecha:"2039-07-22", evento:"Primera aproximacion Kepler-442"},
            _{fecha:"2040-11-30", evento:"Deteccion exoplaneta secundario"},
            _{fecha:"2041-04-29", evento:"ANOMALIA DETECTADA en Kepler-442b"}
        ]
    }).

handle_consulta(Request) :-
    http_parameters(Request, [mision(MisionId, [default("VOYAGER-IX-2041")])]),
    reply_json_dict(_{
        mision_consultada: MisionId,
        estado_sonda: "OPERACIONAL",
        distancia_tierra_km: 1200000000
    }).

:- initialization(main, main).

main :-
    format("~n=== VOYAGER IX — Sistema Experto Prolog ===~n"),
    format("Modo: Datos dinamicos aleatorios~n"),
    format("Puerto: 8001~n~n"),
    http_server(http_dispatch, [port(8001)]),
    thread_get_message(_).