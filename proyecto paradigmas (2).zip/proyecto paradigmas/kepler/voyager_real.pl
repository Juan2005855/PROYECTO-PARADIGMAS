:- use_module(library(http/thread_httpd)).
:- use_module(library(http/http_dispatch)).
:- use_module(library(http/http_json)).
:- use_module(library(random)).

:- http_handler('/analizar', handle_analizar, [method(post)]).
:- http_handler('/health', handle_health, [method(get)]).
:- http_handler('/historial', handle_historial, [method(get)]).
:- http_handler('/consulta', handle_consulta, [method(get)]).

handle_health(_) :-
    reply_json_dict(_{status: "ok", nodo: "VOYAGER_IX", lenguaje: "Prolog"}).

handle_analizar(_Request) :-
    random_between(1000, 9999, N),
    format(atom(Id), 'KPL442B-~w', [N]),
    
    random_between(0, 23, H),
    random_between(0, 59, M),
    format(atom(RA), '~wh~wm', [H, M]),
    
    random_between(-89, 89, D),
    random_between(0, 59, Mi),
    format(atom(Dec), '~w_~w', [D, Mi]),
    
    random_between(65, 90, C1), atom_codes(A1, [C1]),
    random_between(65, 90, C2), atom_codes(A2, [C2]),
    random_between(65, 90, C3), atom_codes(A3, [C3]),
    random_between(1, 9, N1), random_between(1, 9, N2), random_between(1, 9, N3),
    format(atom(Esp), '~w~w-~w~w-~w~w', [A1,N1,A2,N2,A3,N3]),
    
    get_time(T),
    format_time(atom(TS), '%Y-%m-%dT%H:%M:%SZ', T),
    
    random(ConfRaw), Confianza is 0.5 + ConfRaw / 2,
    
    (Confianza > 0.7 -> Clasificacion = 'ANOMALIA_NO_NATURAL';
    Confianza > 0.5 -> Clasificacion = 'FORMACION_NATURAL';
    Confianza > 0.3 -> Clasificacion = 'INTERFERENCIA_SENSOR';
    Clasificacion = 'INDETERMINADO'),
    
    Reporte = _{    
        mission_id: "VOYAGER-IX-2041",
        anomalia_id: Id,
        coordenadas: _{ascension_recta: RA, declinacion: Dec},
        lectura_espectral: _{codigo: Esp},
        clasificacion: Clasificacion,
        confianza: Confianza,
        cadena_reglas: ["regla_geologia_01", "regla_geologia_02"],
        timestamp_utc: TS,
        origen: "VOYAGER_IX"
    },
    format("~n[VOYAGER] Anomalia: ~w | ~w | confianza: ~4f~n", [Id, Clasificacion, Confianza]),
    catch(http_post('http://hermes:8002/relay', json(Reporte), _, [timeout(10)]), _, true),
    reply_json_dict(Reporte).

handle_historial(_) :-
    reply_json_dict(_{
        mission: "VOYAGER-IX-2041",
        estado_sonda: "OPERACIONAL",
        distancia_km: 1200000000,
        historial: [
            _{fecha:"2038-03-15", evento:"Calibracion de sensores"},
            _{fecha:"2039-07-22", evento:"Primera aproximacion Kepler-442"},
            _{fecha:"2040-11-30", evento:"Deteccion exoplaneta secundario"},
            _{fecha:"2041-04-29", evento:"ANOMALIA DETECTADA en Kepler-442b"}
        ]
    }).

handle_consulta(Request) :-
    http_parameters(Request, [mision(MisionId, [default("VOYAGER-IX-2041")])]),
    reply_json_dict(_{
        mision_consultada: MisionId,
        estado_sonda: "OPERACIONAL",
        distancia_tierra_km: 1200000000
    }).

:- initialization(main, main).

main :-
    format("~n=== VOYAGER IX ? Sistema Experto Prolog ===~n"),
    format("Puerto: 8001~n~n"),
    http_server(http_dispatch, [port(8001)]),
    thread_get_message(_).
