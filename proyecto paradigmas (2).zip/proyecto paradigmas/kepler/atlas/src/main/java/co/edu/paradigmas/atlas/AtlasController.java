package co.edu.paradigmas.atlas;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

// ============================================================
// ATLAS Controller
// ============================================================

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/")
public class AtlasController {

    private final RestTemplate rest = new RestTemplate();
    private final ObjectMapper mapper = new ObjectMapper();

    // Contador de misiones activas (140 simuladas + dinámicas)
    private final AtomicInteger misionesActivas = new AtomicInteger(140);

    // Registro de mensajes recibidos (trazabilidad)
    private final List<Map<String, Object>> mensajesRecibidos =
            Collections.synchronizedList(new ArrayList<>());

    // Mapa de agencias responsables por misión
    private static final Map<String, String> AGENCIAS = new HashMap<>();
    static {
        AGENCIAS.put("VOYAGER-IX-2041", "NASA-ESA-CONSORTIUM");
        AGENCIAS.put("DEFAULT", "ATLAS-UNIFICADO");
    }

    // Niveles de prioridad
    private static final Map<String, Integer> PRIORIDAD_POR_CLASIFICACION = new HashMap<>();
    static {
        PRIORIDAD_POR_CLASIFICACION.put("ANOMALIA_NO_NATURAL", 10);  // Máximo histórico
        PRIORIDAD_POR_CLASIFICACION.put("FORMACION_NATURAL",   3);
        PRIORIDAD_POR_CLASIFICACION.put("INTERFERENCIA_SENSOR",2);
        PRIORIDAD_POR_CLASIFICACION.put("INDETERMINADO",       1);
    }

    // ----------------------------------------------------------
    // Health check
    // ----------------------------------------------------------
    @GetMapping("/health")
    public ResponseEntity<Map<String,Object>> health() {
        Map<String,Object> resp = new LinkedHashMap<>();
        resp.put("status", "ok");
        resp.put("nodo", "ATLAS");
        resp.put("lenguaje", "Java");
        resp.put("misiones_activas", misionesActivas.get());
        return ResponseEntity.ok(resp);
    }

    // ----------------------------------------------------------
    // Recibe señal de HERMES, enriquece y despacha a GROUND
    // ----------------------------------------------------------
    @PostMapping("/recibir")
    public ResponseEntity<Map<String,Object>> recibir(
            @RequestBody Map<String, Object> payload) {

        System.out.println("\n[ATLAS] Señal recibida de HERMES");

        String clasificacion = (String) payload.getOrDefault(
                "clasificacion", "INDETERMINADO");
        String missionId     = (String) payload.getOrDefault(
                "mission_id", "UNKNOWN");
        String hashRecibido  = (String) payload.getOrDefault(
                "hash_sha256", "");
        String timestampRelay= (String) payload.getOrDefault(
                "timestamp_relay", Instant.now().toString());

        // 1. Asignar nivel de prioridad
        int prioridad = PRIORIDAD_POR_CLASIFICACION
                .getOrDefault(clasificacion, 1);

        if (prioridad == 10) {
            System.out.println("[ATLAS] *** ALERTA MÁXIMA — Nivel 10 ***");
            System.out.println("[ATLAS] Nunca usado en 17 años de operación");
        }

        // 2. Construir cadena de trazabilidad
        String trazabilidad = buildTrazabilidad(missionId, hashRecibido, timestampRelay);

        // 3. Identificar agencia responsable
        String agencia = AGENCIAS.getOrDefault(missionId, AGENCIAS.get("DEFAULT"));

        // 4. Enriquecer el payload
        Map<String, Object> enriquecido = new LinkedHashMap<>(payload);
        enriquecido.put("nivel_prioridad",      prioridad);
        enriquecido.put("agencia_responsable",  agencia);
        enriquecido.put("misiones_activas",     misionesActivas.get());
        enriquecido.put("trazabilidad",         trazabilidad);
        enriquecido.put("timestamp_atlas",
                DateTimeFormatter.ISO_INSTANT.format(Instant.now()));
        enriquecido.put("nodos_recorridos",
                List.of("VOYAGER_IX", "HERMES", "ATLAS"));

        // 5. Guardar en historial local
        mensajesRecibidos.add(enriquecido);

        System.out.printf("[ATLAS] Clasificación: %s | Prioridad: %d%n",
                clasificacion, prioridad);
        System.out.printf("[ATLAS] Misión: %s | Agencia: %s%n",
                missionId, agencia);
        System.out.println("[ATLAS] Trazabilidad: " + trazabilidad);

        // 6. Despachar a GROUND
        boolean groundOk = despacharAGround(enriquecido);

        Map<String,Object> respuesta = new LinkedHashMap<>();
        respuesta.put("estado",          groundOk ? "DESPACHADO_A_GROUND" : "ERROR_GROUND");
        respuesta.put("nivel_prioridad", prioridad);
        respuesta.put("trazabilidad",    trazabilidad);
        respuesta.put("agencia",         agencia);

        return ResponseEntity.ok(respuesta);
    }

    // ----------------------------------------------------------
    // Consulta inversa: GROUND → ATLAS → HERMES → VOYAGER
    // ----------------------------------------------------------
    @GetMapping("/consultar")
    public ResponseEntity<Map<String,Object>> consultar(
            @RequestParam(defaultValue = "VOYAGER-IX-2041") String mision) {

        System.out.println("[ATLAS] Consulta inversa para misión: " + mision);

        try {
            ResponseEntity<Map> hermesResp = rest.getForEntity(
                    "http://hermes:8002/consultar", Map.class);
            Map<String, Object> datos = hermesResp.getBody();

            Map<String,Object> resp = new LinkedHashMap<>();
            resp.put("fuente",      "VOYAGER_IX_via_HERMES");
            resp.put("mision",      mision);
            resp.put("datos",       datos);
            resp.put("trazabilidad","GROUND→ATLAS→HERMES→VOYAGER_IX");
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            Map<String,Object> err = new LinkedHashMap<>();
            err.put("error",   "No se pudo conectar con HERMES");
            err.put("detalle", e.getMessage());
            return ResponseEntity.status(503).body(err);
        }
    }

    // ----------------------------------------------------------
    // Estado del sistema: misiones activas, historial
    // ----------------------------------------------------------
    @GetMapping("/estado")
    public ResponseEntity<Map<String,Object>> estado() {
        Map<String,Object> resp = new LinkedHashMap<>();
        resp.put("misiones_activas",   misionesActivas.get());
        resp.put("mensajes_procesados",mensajesRecibidos.size());
        resp.put("agencias",           AGENCIAS);
        resp.put("ultimo_mensaje",
                mensajesRecibidos.isEmpty() ? null :
                        mensajesRecibidos.get(mensajesRecibidos.size()-1));
        return ResponseEntity.ok(resp);
    }

    // ----------------------------------------------------------
    // Helpers privados
    // ----------------------------------------------------------

    private String buildTrazabilidad(String missionId,
                                     String hash,
                                     String tsRelay) {
        return String.format(
                "VOYAGER_IX[%s]→HERMES[hash=%s,ts=%s]→ATLAS[ts=%s]",
                missionId,
                hash.length() > 16 ? hash.substring(0, 16) + "..." : hash,
                tsRelay,
                DateTimeFormatter.ISO_INSTANT.format(Instant.now())
        );
    }

    private boolean despacharAGround(Map<String, Object> payload) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<Map<String,Object>> entity =
                    new HttpEntity<>(payload, headers);
            ResponseEntity<Map> resp = rest.postForEntity(
                    "http://ground:8004/persistir", entity, Map.class);
            System.out.println("[ATLAS] GROUND respondió: "
                    + resp.getStatusCode());
            return resp.getStatusCode().is2xxSuccessful();
        } catch (Exception e) {
            System.err.println("[ATLAS] Error al conectar con GROUND: "
                    + e.getMessage());
            return false;
        }
    }
}
