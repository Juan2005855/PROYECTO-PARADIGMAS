package co.edu.paradigmas.atlas;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

// ============================================================
// ATLAS — Estación de Coordinación (Java / Spring Boot)
// Paradigmas del Lenguaje 2026-01
// Gestiona 140 misiones activas, asigna prioridades,
// enriquece mensajes con trazabilidad y los despacha a GROUND.
// ============================================================

@SpringBootApplication
public class AtlasApplication {
    public static void main(String[] args) {
        System.out.println("\n=== ATLAS — Estación de Coordinación Java ===");
        System.out.println("Puerto: 8003");
        System.out.println("Misiones simuladas activas: 140");
        System.out.println("Interoperabilidad: 16 agencias espaciales\n");
        SpringApplication.run(AtlasApplication.class, args);
    }
}
