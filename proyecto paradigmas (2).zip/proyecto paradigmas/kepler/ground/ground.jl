# ============================================================
# GROUND — Sistema de Análisis e Historización
# Paradigmas del Lenguaje 2026-01
# Lenguaje: Julia + MySQL (via ccall directo a libmysqlclient)
# ============================================================

using HTTP
using JSON3
using Dates

# ============================================================
# CONFIGURACIÓN MySQL
# ============================================================
const MYSQL_HOST = get(ENV, "MYSQL_HOST",     "mysql")
const MYSQL_PORT = parse(Int, get(ENV, "MYSQL_PORT", "3306"))
const MYSQL_USER = get(ENV, "MYSQL_USER",     "kepler")
const MYSQL_PASS = get(ENV, "MYSQL_PASSWORD", "keplerpass")
const MYSQL_DB   = get(ENV, "MYSQL_DATABASE", "kepler_db")
const ATLAS_URL  = get(ENV, "ATLAS_URL",      "http://atlas:8003")

# ============================================================
# CONEXIÓN DIRECTA A MySQL via ccall (sin SSL forzado)
# Usamos libmysqlclient directamente para tener control total
# ============================================================

const LIBMYSQL = "libmysqlclient"

# Constantes MySQL
const MYSQL_OPT_SSL_MODE   = Cuint(25)
const MYSQL_SSL_MODE_DISABLED = Cuint(1)
const CLIENT_MULTI_STATEMENTS = Culong(1 << 16)

mutable struct MySQLConn
    handle::Ptr{Cvoid}
end

function mysql_connect()
    handle = ccall((:mysql_init, LIBMYSQL), Ptr{Cvoid}, (Ptr{Cvoid},), C_NULL)
    handle == C_NULL && error("mysql_init falló")

    # FORZAR SSL_MODE_DISABLED antes de conectar
    ssl_disabled = Ref(MYSQL_SSL_MODE_DISABLED)
    ccall((:mysql_options, LIBMYSQL), Cint,
          (Ptr{Cvoid}, Cuint, Ptr{Cvoid}),
          handle, MYSQL_OPT_SSL_MODE, ssl_disabled)

    result = ccall((:mysql_real_connect, LIBMYSQL), Ptr{Cvoid},
                   (Ptr{Cvoid}, Cstring, Cstring, Cstring,
                    Cstring, Cuint, Cstring, Culong),
                   handle,
                   MYSQL_HOST, MYSQL_USER, MYSQL_PASS,
                   MYSQL_DB, Cuint(MYSQL_PORT),
                   C_NULL, CLIENT_MULTI_STATEMENTS)

    if result == C_NULL
        err = unsafe_string(ccall((:mysql_error, LIBMYSQL),
                                   Cstring, (Ptr{Cvoid},), handle))
        ccall((:mysql_close, LIBMYSQL), Cvoid, (Ptr{Cvoid},), handle)
        error("mysql_real_connect falló: $err")
    end
    return MySQLConn(handle)
end

function mysql_close(conn::MySQLConn)
    ccall((:mysql_close, LIBMYSQL), Cvoid, (Ptr{Cvoid},), conn.handle)
end

function mysql_query(conn::MySQLConn, sql::String)
    ret = ccall((:mysql_query, LIBMYSQL), Cint,
                (Ptr{Cvoid}, Cstring), conn.handle, sql)
    ret != 0 && begin
        err = unsafe_string(ccall((:mysql_error, LIBMYSQL),
                                   Cstring, (Ptr{Cvoid},), conn.handle))
        error("mysql_query error: $err\nSQL: $sql")
    end
    return ret
end

function mysql_query_rows(conn::MySQLConn, sql::String)
    mysql_query(conn, sql)
    res = ccall((:mysql_store_result, LIBMYSQL),
                Ptr{Cvoid}, (Ptr{Cvoid},), conn.handle)
    res == C_NULL && return Vector{Vector{String}}()

    num_fields = ccall((:mysql_num_fields, LIBMYSQL), Cuint, (Ptr{Cvoid},), res)
    rows = Vector{Vector{String}}()

    while true
        row = ccall((:mysql_fetch_row, LIBMYSQL),
                    Ptr{Ptr{Cchar}}, (Ptr{Cvoid},), res)
        row == C_NULL && break
        cols = String[]
        for i in 0:num_fields-1
            ptr = unsafe_load(row, i+1)
            push!(cols, ptr == C_NULL ? "" : unsafe_string(ptr))
        end
        push!(rows, cols)
    end
    ccall((:mysql_free_result, LIBMYSQL), Cvoid, (Ptr{Cvoid},), res)
    return rows
end

function mysql_escape(conn::MySQLConn, s::AbstractString)
    str = string(s)
    buf = Vector{UInt8}(undef, length(str)*2 + 1)
    n = ccall((:mysql_real_escape_string, LIBMYSQL), Culong,
              (Ptr{Cvoid}, Ptr{UInt8}, Cstring, Culong),
              conn.handle, buf, str, Culong(ncodeunits(str)))
    return String(buf[1:n])
end

# ============================================================
# INICIALIZACIÓN DEL ESQUEMA
# ============================================================
function init_db()
    for attempt in 1:15
        try
            conn = mysql_connect()
            stmts = [
                """CREATE TABLE IF NOT EXISTS misiones (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    mission_id VARCHAR(64) UNIQUE NOT NULL,
                    nombre VARCHAR(128), agencia VARCHAR(128),
                    estado VARCHAR(32) DEFAULT 'ACTIVA',
                    lanzamiento DATETIME,
                    creado_en DATETIME DEFAULT CURRENT_TIMESTAMP)""",
                """CREATE TABLE IF NOT EXISTS sondas (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    mission_id VARCHAR(64) NOT NULL,
                    estado_sensores VARCHAR(32) DEFAULT 'OPERACIONAL',
                    distancia_km BIGINT, ultima_senal DATETIME,
                    FOREIGN KEY (mission_id) REFERENCES misiones(mission_id))""",
                """CREATE TABLE IF NOT EXISTS anomalias (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    mission_id VARCHAR(64) NOT NULL,
                    anomalia_id VARCHAR(64) UNIQUE NOT NULL,
                    clasificacion VARCHAR(64), confianza FLOAT,
                    coordenadas JSON, lectura_espectral JSON,
                    cadena_reglas JSON, timestamp_obs DATETIME,
                    creado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (mission_id) REFERENCES misiones(mission_id))""",
                """CREATE TABLE IF NOT EXISTS transmisiones (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    anomalia_id VARCHAR(64) NOT NULL,
                    hash_sha256 VARCHAR(64), hermes_id VARCHAR(64),
                    nivel_prioridad INT DEFAULT 1,
                    trazabilidad TEXT,
                    timestamp_relay DATETIME, timestamp_atlas DATETIME,
                    timestamp_ground DATETIME DEFAULT CURRENT_TIMESTAMP,
                    integridad_ok BOOLEAN DEFAULT TRUE,
                    FOREIGN KEY (anomalia_id) REFERENCES anomalias(anomalia_id))""",
                """CREATE TABLE IF NOT EXISTS resumenes (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    mission_id VARCHAR(64) NOT NULL,
                    contenido JSON, nivel_alerta INT DEFAULT 1,
                    generado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (mission_id) REFERENCES misiones(mission_id))""",
                """INSERT IGNORE INTO misiones
                   (mission_id,nombre,agencia,estado,lanzamiento) VALUES
                   ('VOYAGER-IX-2041','Voyager IX Kepler-442',
                    'NASA-ESA-CONSORTIUM','ACTIVA','2024-03-01 08:00:00')""",
                """INSERT IGNORE INTO sondas
                   (mission_id,estado_sensores,distancia_km,ultima_senal)
                   VALUES ('VOYAGER-IX-2041','OPERACIONAL',1200000000,NOW())"""
            ]
            for s in stmts
                mysql_query(conn, s)
            end
            mysql_close(conn)
            println("[GROUND] Esquema MySQL inicializado OK")
            return
        catch e
            println("[GROUND] MySQL no listo (intento $attempt/15): $e")
            sleep(3)
        end
    end
    error("[GROUND] No se pudo conectar a MySQL después de 15 intentos")
end

# ============================================================
# HELPERS
# ============================================================
function parse_ts(s)
    s = string(s)
    length(s) >= 19 ? replace(s[1:19], "T"=>" ") : s
end

function count_query(conn, sql, param)
    esc = mysql_escape(conn, param)
    rows = mysql_query_rows(conn, replace(sql, "?" => "'$esc'"))
    isempty(rows) ? 0 : parse(Int, rows[1][1])
end

function generar_resumen(conn, mission_id, anomalia_id,
                          clasificacion, confianza, prioridad)
    total_anomalias = count_query(conn,
        "SELECT COUNT(*) FROM anomalias WHERE mission_id=?", mission_id)
    total_trans = count_query(conn,
        "SELECT COUNT(*) FROM transmisiones t
         JOIN anomalias a ON t.anomalia_id=a.anomalia_id
         WHERE a.mission_id=?", mission_id)

    mensaje = prioridad >= 10 ?
        "ALERTA MAXIMA — POSIBLE ESTRUCTURA ARTIFICIAL DETECTADA" :
        "Ultimo hallazgo: $clasificacion ($(round(Int,confianza*100))%)"

    Dict("mision"=>mission_id, "ultimo_hallazgo"=>anomalia_id,
         "clasificacion"=>clasificacion, "confianza"=>confianza,
         "nivel_alerta"=>prioridad, "alerta_maxima"=>prioridad>=10,
         "total_anomalias"=>total_anomalias,
         "total_transmisiones"=>total_trans,
         "mensaje_pantalla"=>mensaje,
         "generado_en"=>string(now(UTC)))
end

# ============================================================
# HANDLERS HTTP
# ============================================================
function handle_health(req)
    HTTP.Response(200, ["Content-Type"=>"application/json"],
        JSON3.write(Dict("status"=>"ok","nodo"=>"GROUND","lenguaje"=>"Julia")))
end

function handle_persistir(req)
    payload = JSON3.read(String(req.body))

    mission_id    = string(get(payload, :mission_id,          "UNKNOWN"))
    anomalia_id   = string(get(payload, :anomalia_id,         "UNKNOWN"))
    clasificacion = string(get(payload, :clasificacion,       "INDETERMINADO"))
    confianza     = Float64(get(payload, :confianza,          0.0))
    hash_sha256   = string(get(payload, :hash_sha256,         ""))
    hermes_id     = string(get(payload, :hermes_id,           "HERMES-SAT-01"))
    trazabilidad  = string(get(payload, :trazabilidad,        ""))
    prioridad     = Int(get(payload, :nivel_prioridad,        1))
    agencia       = string(get(payload, :agencia_responsable, "N/A"))
    cadena_reglas = JSON3.write(get(payload, :cadena_reglas,  []))
    ts_relay      = parse_ts(get(payload, :timestamp_relay,   string(now(UTC))))
    ts_atlas      = parse_ts(get(payload, :timestamp_atlas,   string(now(UTC))))
    coordenadas   = JSON3.write(get(payload, :coordenadas,    Dict()))
    espectral     = JSON3.write(get(payload, :lectura_espectral, Dict()))

    println("\n[GROUND] Persistiendo: $mission_id | $clasificacion | P=$prioridad")

    conn = mysql_connect()
    try
        # Helper local usando la conexión abierta
        e(s) = mysql_escape(conn, string(s))

        mysql_query(conn, """INSERT INTO misiones
            (mission_id,nombre,agencia,lanzamiento) VALUES
            ('$(e(mission_id))','Mision $(e(mission_id))',
             '$(e(agencia))','2024-01-01 00:00:00')
            ON DUPLICATE KEY UPDATE agencia='$(e(agencia))'""")

        mysql_query(conn, """INSERT INTO sondas
            (mission_id,estado_sensores,distancia_km,ultima_senal)
            VALUES ('$(e(mission_id))','OPERACIONAL',1200000000,NOW())
            ON DUPLICATE KEY UPDATE ultima_senal=NOW()""")

        mysql_query(conn, """INSERT IGNORE INTO anomalias
            (mission_id,anomalia_id,clasificacion,confianza,
             coordenadas,lectura_espectral,cadena_reglas,timestamp_obs)
            VALUES ('$(e(mission_id))','$(e(anomalia_id))',
                    '$(e(clasificacion))',$confianza,
                    '$(e(coordenadas))','$(e(espectral))',
                    '$(e(cadena_reglas))',NOW())""")

        mysql_query(conn, """INSERT INTO transmisiones
            (anomalia_id,hash_sha256,hermes_id,nivel_prioridad,
             trazabilidad,timestamp_relay,timestamp_atlas,integridad_ok)
            VALUES ('$(e(anomalia_id))','$(e(hash_sha256))',
                    '$(e(hermes_id))',$prioridad,
                    '$(e(trazabilidad))',
                    '$(e(ts_relay))','$(e(ts_atlas))',1)""")

        resumen = generar_resumen(conn, mission_id, anomalia_id,
                                   clasificacion, confianza, prioridad)
        resumen_str = JSON3.write(resumen)
        # Escapar solo las comillas simples para SQL, no el JSON completo
        resumen_sql = replace(resumen_str, "'" => "\\'")
        mysql_query(conn, """INSERT INTO resumenes
            (mission_id,contenido,nivel_alerta)
            VALUES ('$(e(mission_id))','$resumen_sql',$prioridad)""")

        println("[GROUND] Persistido OK")
        return HTTP.Response(200, ["Content-Type"=>"application/json"],
            JSON3.write(Dict("estado"=>"PERSISTIDO",
                             "anomalia_id"=>anomalia_id,
                             "prioridad"=>prioridad,
                             "resumen"=>resumen)))
    catch e
        println("[GROUND] Error al persistir: $e")
        return HTTP.Response(500, ["Content-Type"=>"application/json"],
            JSON3.write(Dict("error"=>string(e))))
    finally
        mysql_close(conn)
    end
end

function handle_historial(req, mission_id)
    conn = mysql_connect()
    try
        mid_esc = mysql_escape(conn, mission_id)
        rows = mysql_query_rows(conn,
            "SELECT anomalia_id,clasificacion,confianza,creado_en
             FROM anomalias WHERE mission_id='$mid_esc'
             ORDER BY creado_en DESC")
        anomalias = [Dict("anomalia_id"=>r[1],"clasificacion"=>r[2],
                          "confianza"=>r[3],"creado_en"=>r[4]) for r in rows]
        res_rows = mysql_query_rows(conn,
            "SELECT contenido,nivel_alerta FROM resumenes
             WHERE mission_id='$mid_esc'
             ORDER BY generado_en DESC LIMIT 1")
        ultimo = isempty(res_rows) ? nothing :
                 Dict("contenido"=>JSON3.read(res_rows[1][1]),
                      "nivel_alerta"=>res_rows[1][2])
        return HTTP.Response(200, ["Content-Type"=>"application/json"],
            JSON3.write(Dict("mission_id"=>mission_id,
                             "anomalias"=>anomalias,
                             "ultimo_resumen"=>ultimo)))
    catch e
        println("[GROUND] Error historial: $e")
        return HTTP.Response(200, ["Content-Type"=>"application/json"],
            JSON3.write(Dict("mission_id"=>mission_id,
                             "anomalias"=>[], "ultimo_resumen"=>nothing)))
    finally
        mysql_close(conn)
    end
end

function handle_resumenes(req)
    conn = mysql_connect()
    try
        rows = mysql_query_rows(conn,
            "SELECT mission_id,contenido,nivel_alerta,generado_en
             FROM resumenes ORDER BY generado_en DESC LIMIT 10")
        resumenes = [Dict("mission_id"=>r[1],
                          "contenido"=>JSON3.read(r[2]),
                          "nivel_alerta"=>r[3],
                          "generado_en"=>r[4]) for r in rows]
        return HTTP.Response(200, ["Content-Type"=>"application/json"],
            JSON3.write(Dict("resumenes"=>resumenes)))
    catch e
        println("[GROUND] Error resumenes: $e")
        return HTTP.Response(200, ["Content-Type"=>"application/json"],
            JSON3.write(Dict("resumenes"=>[])))
    finally
        mysql_close(conn)
    end
end

function handle_consultar(req)
    params = HTTP.queryparams(HTTP.URI(req.target))
    mision = get(params, "mision", "VOYAGER-IX-2041")
    println("[GROUND] Flujo inverso para misión: $mision")
    try
        resp = HTTP.get("$ATLAS_URL/consultar?mision=$mision"; readtimeout=10)
        return HTTP.Response(200, ["Content-Type"=>"application/json"], resp.body)
    catch e
        return HTTP.Response(503, ["Content-Type"=>"application/json"],
            JSON3.write(Dict("error"=>string(e))))
    end
end

# ============================================================
# ROUTER
# ============================================================
function router(req::HTTP.Request)
    try
        path   = HTTP.URI(req.target).path
        method = req.method
        if     method=="GET"  && path=="/health"       ; handle_health(req)
        elseif method=="POST" && path=="/persistir"    ; handle_persistir(req)
        elseif method=="GET"  && path=="/resumenes"    ; handle_resumenes(req)
        elseif method=="GET"  && path=="/consultar"    ; handle_consultar(req)
        elseif method=="GET"  && startswith(path,"/historial/")
            parts = split(path, "/")
            mission_id = length(parts) >= 3 ? parts[3] : "VOYAGER-IX-2041"
            handle_historial(req, mission_id)
        else
            HTTP.Response(404, ["Content-Type"=>"application/json"],
                JSON3.write(Dict("error"=>"ruta no encontrada")))
        end
    catch e
        println("[GROUND] Error router: $e")
        HTTP.Response(500, ["Content-Type"=>"application/json"],
            JSON3.write(Dict("error"=>string(e))))
    end
end

# ============================================================
# MAIN
# ============================================================
println("\n=== GROUND — Centro de Control Unificado (Julia) ===")
println("Puerto: 8004  |  Motor: MySQL via ccall (sin SSL)")
println("Búnker: montañas suizas (simulado)\n")

init_db()

println("[GROUND] Servidor HTTP activo en puerto 8004...")
HTTP.serve(router, "0.0.0.0", 8004)
