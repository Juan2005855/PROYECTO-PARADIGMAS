-- ============================================================
-- GROUND — Esquema MySQL
-- Proyecto Kepler — Paradigmas del Lenguaje 2026-01
-- ============================================================

CREATE DATABASE IF NOT EXISTS kepler_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE kepler_db;

-- ------------------------------------------------------------
-- 1. Misiones activas
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS misiones (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    mission_id  VARCHAR(64) UNIQUE NOT NULL
                    COMMENT 'Identificador único de la misión',
    nombre      VARCHAR(128),
    agencia     VARCHAR(128)
                    COMMENT 'Agencia espacial responsable',
    estado      ENUM('ACTIVA','COMPLETADA','FALLIDA')
                    DEFAULT 'ACTIVA',
    lanzamiento DATETIME,
    creado_en   DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_mission_id (mission_id)
) COMMENT = 'Registro de misiones espaciales activas';

-- ------------------------------------------------------------
-- 2. Estado de sondas
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sondas (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    mission_id       VARCHAR(64) NOT NULL,
    estado_sensores  ENUM('OPERACIONAL','DEGRADADO','FALLO')
                        DEFAULT 'OPERACIONAL',
    distancia_km     BIGINT COMMENT 'Distancia actual a la Tierra en km',
    ultima_senal     DATETIME,
    FOREIGN KEY (mission_id) REFERENCES misiones(mission_id)
        ON DELETE CASCADE,
    INDEX idx_sonda_mision (mission_id)
) COMMENT = 'Estado actual de cada sonda';

-- ------------------------------------------------------------
-- 3. Anomalías detectadas
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS anomalias (
    id                INT AUTO_INCREMENT PRIMARY KEY,
    mission_id        VARCHAR(64) NOT NULL,
    anomalia_id       VARCHAR(64) UNIQUE NOT NULL,
    clasificacion     VARCHAR(64)
                        COMMENT 'Resultado del sistema experto Prolog',
    confianza         FLOAT
                        COMMENT 'Valor entre 0 y 1',
    coordenadas       JSON
                        COMMENT 'Ascensión recta y declinación',
    lectura_espectral JSON
                        COMMENT 'Datos espectrales crudos',
    cadena_reglas     JSON
                        COMMENT 'Reglas Prolog que llevaron a la conclusión',
    timestamp_obs     DATETIME
                        COMMENT 'Timestamp UTC de la observación',
    creado_en         DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (mission_id) REFERENCES misiones(mission_id)
        ON DELETE CASCADE,
    INDEX idx_anomalia_mision (mission_id),
    INDEX idx_clasificacion (clasificacion)
) COMMENT = 'Anomalías detectadas por las sondas';

-- ------------------------------------------------------------
-- 4. Trazabilidad de transmisiones
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS transmisiones (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    anomalia_id      VARCHAR(64) NOT NULL,
    hash_sha256      VARCHAR(64)
                        COMMENT 'Hash calculado por HERMES (Haskell)',
    hermes_id        VARCHAR(64),
    nivel_prioridad  INT DEFAULT 1
                        COMMENT '1=normal … 10=máximo histórico',
    trazabilidad     TEXT
                        COMMENT 'Cadena VOYAGER→HERMES→ATLAS con timestamps',
    timestamp_relay  DATETIME
                        COMMENT 'Cuando HERMES retransmitió',
    timestamp_atlas  DATETIME
                        COMMENT 'Cuando ATLAS enriqueció',
    timestamp_ground DATETIME DEFAULT CURRENT_TIMESTAMP
                        COMMENT 'Cuando GROUND persistió',
    integridad_ok    BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (anomalia_id) REFERENCES anomalias(anomalia_id)
        ON DELETE CASCADE,
    INDEX idx_trans_anomalia (anomalia_id),
    INDEX idx_prioridad (nivel_prioridad)
) COMMENT = 'Trazabilidad completa de cada transmisión';

-- ------------------------------------------------------------
-- 5. Resúmenes consolidados (lo que aparece en pantalla)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS resumenes (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    mission_id   VARCHAR(64) NOT NULL,
    contenido    JSON
                    COMMENT 'Resumen cruzado con historial previo',
    nivel_alerta INT DEFAULT 1,
    generado_en  DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (mission_id) REFERENCES misiones(mission_id)
        ON DELETE CASCADE,
    INDEX idx_resumen_mision (mission_id)
) COMMENT = 'Resúmenes consolidados visibles en pantalla del Centro de Control';

-- ------------------------------------------------------------
-- Datos de ejemplo: misión histórica para demostrar historial
-- ------------------------------------------------------------
INSERT IGNORE INTO misiones
    (mission_id, nombre, agencia, estado, lanzamiento)
VALUES
    ('VOYAGER-IX-2041',
    'Voyager IX — Misión Kepler-442',
    'NASA-ESA-CONSORTIUM',
    'ACTIVA',
    '2024-03-01 08:00:00');

INSERT IGNORE INTO sondas
    (mission_id, estado_sensores, distancia_km, ultima_senal)
VALUES
    ('VOYAGER-IX-2041', 'OPERACIONAL', 1200000000, NOW());
