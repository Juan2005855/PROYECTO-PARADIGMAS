const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  HeadingLevel, AlignmentType, BorderStyle, WidthType, ShadingType,
  LevelFormat, NumberFormat, Header, Footer, PageBreak,
  PageNumber, NumberOfPages
} = require("docx");
const fs = require("fs");

const BORDER = { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" };
const BORDERS = { top: BORDER, bottom: BORDER, left: BORDER, right: BORDER };
const BLUE = "1F4E79";
const LIGHT_BLUE = "D6E4F0";
const ACCENT = "2E86AB";

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 180 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: ACCENT, space: 4 } },
    children: [new TextRun({ text, bold: true, size: 32, color: BLUE, font: "Arial" })]
  });
}

function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 280, after: 120 },
    children: [new TextRun({ text, bold: true, size: 26, color: ACCENT, font: "Arial" })]
  });
}

function h3(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3,
    spacing: { before: 200, after: 80 },
    children: [new TextRun({ text, bold: true, size: 24, color: "444444", font: "Arial" })]
  });
}

function p(text, options = {}) {
  return new Paragraph({
    spacing: { after: 120, line: 276 },
    children: [new TextRun({ text, size: 22, font: "Arial", ...options })]
  });
}

function pMixed(...runs) {
  return new Paragraph({
    spacing: { after: 120, line: 276 },
    children: runs.map(r =>
      typeof r === "string"
        ? new TextRun({ text: r, size: 22, font: "Arial" })
        : new TextRun({ size: 22, font: "Arial", ...r })
    )
  });
}

function bullet(text, level = 0) {
  return new Paragraph({
    numbering: { reference: "bullets", level },
    spacing: { after: 80 },
    children: [new TextRun({ text, size: 22, font: "Arial" })]
  });
}

function code(text) {
  return new Paragraph({
    spacing: { after: 80, before: 80 },
    indent: { left: 720 },
    children: [new TextRun({
      text, font: "Courier New", size: 18, color: "C0392B"
    })]
  });
}

function makeTable(headers, rows, colWidths) {
  const headerRow = new TableRow({
    tableHeader: true,
    children: headers.map((h, i) => new TableCell({
      borders: BORDERS,
      width: { size: colWidths[i], type: WidthType.DXA },
      margins: { top: 80, bottom: 80, left: 120, right: 120 },
      shading: { fill: LIGHT_BLUE, type: ShadingType.CLEAR },
      children: [new Paragraph({
        children: [new TextRun({ text: h, bold: true, size: 20, font: "Arial", color: BLUE })]
      })]
    }))
  });
  const dataRows = rows.map(row => new TableRow({
    children: row.map((cell, i) => new TableCell({
      borders: BORDERS,
      width: { size: colWidths[i], type: WidthType.DXA },
      margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: [new Paragraph({
        children: [new TextRun({ text: cell, size: 20, font: "Arial" })]
      })]
    }))
  }));
  return new Table({
    width: { size: colWidths.reduce((a, b) => a + b, 0), type: WidthType.DXA },
    columnWidths: colWidths,
    rows: [headerRow, ...dataRows]
  });
}

function spacer() {
  return new Paragraph({ spacing: { after: 120 }, children: [] });
}

// ============================================================
// DOCUMENT
// ============================================================

const doc = new Document({
  numbering: {
    config: [{
      reference: "bullets",
      levels: [
        { level: 0, format: LevelFormat.BULLET, text: "\u2022",
          alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } } },
        { level: 1, format: LevelFormat.BULLET, text: "\u25E6",
          alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 1080, hanging: 360 } } } },
      ]
    }]
  },
  styles: {
    default: { document: { run: { font: "Arial", size: 22 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, font: "Arial", color: BLUE },
        paragraph: { spacing: { before: 360, after: 180 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 26, bold: true, font: "Arial", color: ACCENT },
        paragraph: { spacing: { before: 280, after: 120 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 24, bold: true, font: "Arial", color: "444444" },
        paragraph: { spacing: { before: 200, after: 80 }, outlineLevel: 2 } },
    ]
  },
  sections: [{
    properties: {
      page: {
        size: { width: 11906, height: 16838 },
        margin: { top: 1134, right: 1134, bottom: 1134, left: 1134 }
      }
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: ACCENT, space: 4 } },
          children: [
            new TextRun({ text: "Proyecto Kepler — La última transmisión de Voyager IX", size: 18, color: "888888", font: "Arial" }),
            new TextRun({ text: "   |   Paradigmas del Lenguaje 2026-01", size: 18, color: "AAAAAA", font: "Arial" }),
          ]
        })]
      })
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          border: { top: { style: BorderStyle.SINGLE, size: 4, color: ACCENT, space: 4 } },
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({ text: "John Harold Morales Velez   |   Página ", size: 18, color: "888888", font: "Arial" }),
          ]
        })]
      })
    },
    children: [

      // ========================================================
      // PORTADA
      // ========================================================
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 1440, after: 480 },
        children: [new TextRun({ text: "PROYECTO KEPLER", bold: true, size: 56, color: BLUE, font: "Arial" })]
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { after: 240 },
        children: [new TextRun({ text: "La última transmisión de Voyager IX", size: 36, color: ACCENT, font: "Arial", italics: true })]
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { after: 720 },
        children: [new TextRun({ text: "Paradigmas del Lenguaje — 2026-01", size: 24, color: "666666", font: "Arial" })]
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { after: 120 },
        children: [new TextRun({ text: "John Harold Morales Velez", bold: true, size: 28, font: "Arial" })]
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { after: 120 },
        children: [new TextRun({ text: "Ingeniería de Sistemas", size: 22, color: "666666", font: "Arial" })]
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { after: 120 },
        children: [new TextRun({ text: "2026", size: 22, color: "888888", font: "Arial" })]
      }),
      new Paragraph({ children: [new PageBreak()] }),

      // ========================================================
      // 1. DESCRIPCIÓN DE LA ARQUITECTURA
      // ========================================================
      h1("1. Descripción de la Arquitectura del Sistema"),
      spacer(),
      p("El sistema Proyecto Kepler simula la cadena de transmisión de datos entre una sonda espacial y el centro de control en la Tierra. Está compuesto por cinco nodos que se comunican vía HTTP, cada uno implementado en un lenguaje de programación distinto, elegido por su paradigma natural para el rol que desempeña."),
      spacer(),

      h2("1.1 Visión General del Flujo"),
      p("El flujo de datos sigue dos direcciones:"),
      bullet("Flujo directo: Voyager IX (Prolog) → HERMES (Haskell) → ATLAS (Java) → GROUND (Python/MySQL)"),
      bullet("Flujo inverso: GROUND → ATLAS → HERMES → Voyager IX, iniciado por el cliente Julia"),
      spacer(),

      h2("1.2 Nodos del Sistema"),
      spacer(),

      makeTable(
        ["Nodo", "Lenguaje", "Puerto", "Paradigma Principal", "Responsabilidad"],
        [
          ["Voyager IX", "Prolog", "8001", "Lógico / Declarativo", "Sistema experto: clasifica anomalías usando base de reglas"],
          ["HERMES", "Haskell", "8002", "Funcional puro", "Verificación SHA-256, corrección de errores, relay canónico"],
          ["ATLAS", "Java", "8003", "Orientado a objetos", "Coordinación de 140 misiones, enriquecimiento y trazabilidad"],
          ["GROUND", "Julia + MySQL", "8004", "Científico / Imperativo", "Persistencia en MySQL, historización y resúmenes consolidados"],
          ["Cliente Julia", "Julia", "—", "Científico / Numérico", "Orquestación del flujo completo y análisis espectral"],
        ],
        [1600, 1400, 900, 1800, 2660]
      ),
      spacer(),

      h2("1.3 Justificación de cada lenguaje en su rol"),
      spacer(),

      h3("Prolog — Voyager IX (Sistema Experto)"),
      p("Prolog es un lenguaje de programación lógica basado en cláusulas de Horn. Su naturaleza declarativa lo hace ideal para sistemas expertos: en lugar de programar cómo clasificar una anomalía paso a paso, se declaran las reglas que definen qué es una anomalía natural, qué es interferencia de sensor y qué constituye una estructura no natural. El motor de inferencia de Prolog recorre estas reglas automáticamente hasta alcanzar una conclusión, y la cadena de reglas aplicadas se obtiene de forma natural como traza de la inferencia. Ningún otro lenguaje del conjunto permite expresar este tipo de razonamiento por descarte con tanta economía semántica."),
      spacer(),

      h3("Haskell — HERMES (Satélite de Retransmisión)"),
      p("El enunciado establece explícitamente que HERMES fue diseñado con una filosofía muy particular: cada transformación que aplica sobre los datos es una función pura. Haskell es el único lenguaje del conjunto donde la pureza funcional es enforced por el sistema de tipos: las funciones que no tienen efectos laterales no pueden ejecutar IO, y cualquier efecto debe ser declarado explícitamente en la firma de tipos. Esto garantiza que computeHash, verifyIntegrity, applyErrorCorrection y buildHermesPackage son matemáticamente puras: el mismo input siempre produce el mismo output, sin estados ocultos, tal como requiere el diseño de HERMES. Los efectos (enviar HTTP a ATLAS) quedan confinados al borde del sistema en funciones con tipo IO ()."),
      spacer(),

      h3("Java — ATLAS (Estación de Coordinación)"),
      p("El enunciado describe ATLAS como el nodo que gestiona 140 misiones simultáneas, notifica a equipos en cuatro continentes y se conecta con dieciséis agencias con sistemas distintos, lenguajes distintos y décadas de infraestructura heredada. Este perfil corresponde precisamente al ecosistema donde Java ha dominado durante tres décadas: interoperabilidad empresarial, robustez bajo carga concurrente y ecosistema de integración maduro. Spring Boot proporciona el servidor HTTP con manejo de concurrencia transparente. El paradigma orientado a objetos permite modelar naturalmente las entidades del dominio (misiones, agencias, niveles de prioridad) y encapsular la lógica de enriquecimiento de mensajes."),
      spacer(),

      h3("Julia — GROUND (Persistencia) y Cliente Orquestador"),
      p("Julia asume dos roles en el sistema. Como GROUND, conecta con MySQL usando la librería MySQL.jl para persistir las cinco entidades del esquema relacional: misiones, sondas, anomalías, transmisiones y resúmenes. Julia maneja la concurrencia del servidor HTTP con HTTP.jl y serializa/deserializa JSON con JSON3.jl. Como cliente orquestador, realiza el análisis espectral científico de los datos de Kepler-442b: calcula la temperatura efectiva usando la ley de Stefan-Boltzmann, normaliza el albedo y computa un índice de habitabilidad. Estas operaciones numéricas son ciudadanas de primera clase en Julia, con sintaxis matemática natural y performance comparable a C."),
      spacer(),

      new Paragraph({ children: [new PageBreak()] }),

      // ========================================================
      // 2. DECISIÓN TÉCNICA
      // ========================================================
      h1("2. Decisión Técnica: Alternativa Descartada"),
      spacer(),

      h2("2.1 El dilema: ¿Quién implementa HERMES?"),
      p("Durante el diseño del sistema, el equipo evaluó dos alternativas para implementar el nodo HERMES:"),
      spacer(),

      makeTable(
        ["Criterio", "Opción A: Haskell (elegida)", "Opción B: Java (descartada)"],
        [
          ["Pureza funcional", "Garantizada por el sistema de tipos", "Opcional, no enforced"],
          ["Funciones sin efectos", "El compilador verifica que no hay IO oculto", "El programador debe disciplinarse manualmente"],
          ["Hash SHA-256", "cryptonite: librería bien auditada", "java.security.MessageDigest: también válida"],
          ["Detección de efectos ocultos", "Error de compilación si se intenta", "Solo detectable en code review"],
          ["Curva de aprendizaje", "Alta (tipos, mónadas)", "Baja (ya usada en ATLAS)"],
          ["Alineación con el enunciado", "Directa: el enunciado describe funciones puras", "Indirecta: OOP no refleja el diseño descrito"],
        ],
        [2200, 3000, 3000]
      ),
      spacer(),

      h2("2.2 Por qué se descartó Java para HERMES"),
      p("La razón principal para descartar Java no fue técnica sino semántica: el enunciado describe HERMES como un sistema diseñado para que cada transformación sea una función pura, sin estados ocultos, sin efectos laterales que nadie pueda predecir. En Java, nada impide que un método que se llama computeHash() modifique un campo de instancia, escriba un log, o lance una excepción con efectos laterales. La pureza en Java es una convención de programación, no una garantía del lenguaje."),
      spacer(),
      p("En Haskell, si computeHash :: ByteString -> Text no tiene IO en su tipo, es físicamente imposible que tenga efectos laterales. El compilador lo garantiza. Esta alineación entre la filosofía de HERMES descrita en el enunciado y las garantías del sistema de tipos de Haskell fue el argumento decisivo para elegirlo, a pesar de su mayor complejidad de implementación."),
      spacer(),
      p("El costo de esta decisión fue real: la imagen Docker de Haskell es significativamente más pesada que la de Java, y el tiempo de compilación con Cabal es mayor. Sin embargo, el equipo consideró que estos costos operacionales eran aceptables dado que reflejan con precisión el contrato semántico que el enunciado establece para HERMES."),
      spacer(),

      new Paragraph({ children: [new PageBreak()] }),

      // ========================================================
      // 3. PROBLEMAS ENCONTRADOS
      // ========================================================
      h1("3. Problemas Encontrados y Soluciones"),
      spacer(),

      h2("Problema 1: Interoperabilidad de tipos JSON entre Prolog y Haskell"),
      h3("Descripción"),
      p("Prolog serializa términos con library(http/http_json), pero los átomos de Prolog (como 'ANOMALIA_NO_NATURAL') se serializan como strings JSON normales. Haskell con Aeson espera tipos estrictamente tipados. Cuando cadena_reglas en Prolog era una lista de átomos, Aeson fallaba al deserializar porque esperaba [Text] pero recibía valores que a veces llegaban como null cuando la lista estaba vacía."),
      h3("Solución"),
      p("Se añadió un campo opcional en el parser Haskell usando (.:?) con valor por defecto [] para cadena_reglas, y se forzó en Prolog que findall/3 siempre retorna lista (posiblemente vacía) en lugar de fallar. Adicionalmente, applyErrorCorrection en Haskell re-serializa el JSON a formato canónico antes de calcular el hash, normalizando cualquier inconsistencia de representación entre los lenguajes."),
      spacer(),

      h2("Problema 2: Inicialización de MySQL antes de que GROUND arranque"),
      h3("Descripción"),
      p("Docker Compose no garantiza que MySQL esté completamente inicializado cuando el contenedor ground inicia, incluso con depends_on y condition: service_healthy. El healthcheck de MySQL responde 'healthy' cuando el proceso está activo, pero el script de inicialización schema.sql puede no haber terminado de ejecutarse todavía."),
      h3("Solución"),
      p("Se implementó un mecanismo de reintentos en ground.py: la función init_db() se envuelve en un bucle con sleep(2) que reintenta hasta 10 veces antes de fallar. Esto desacopla el arranque del servicio HTTP (que puede responder /health inmediatamente) de la disponibilidad de la base de datos, permitiendo que el resto del sistema arranque sin esperar."),
      spacer(),

      h2("Problema 3: Flujo asíncrono entre HERMES y ATLAS"),
      h3("Descripción"),
      p("HERMES reenvía a ATLAS en un hilo separado (forkIO) para no bloquear la respuesta a Voyager IX. Esto causó una condición de carrera en las pruebas: el cliente Julia verificaba la persistencia en GROUND inmediatamente después de recibir respuesta de HERMES, antes de que ATLAS hubiera procesado y enviado a GROUND."),
      h3("Solución"),
      p("El cliente Julia incorpora un sleep(1) explícito entre el paso de HERMES y la verificación en GROUND, dando tiempo al pipeline asíncrono para completarse. Para producción, la solución correcta sería implementar un mecanismo de confirmación (acknowledgment) donde ATLAS notifica a HERMES que GROUND persistió exitosamente, pero para los propósitos de la demo este enfoque pragmático es suficiente."),
      spacer(),

      h2("Problema 4: Haskell — dependencias de cryptonite con GHC"),
      h3("Descripción"),
      p("La librería cryptonite requiere la librería de sistema libgmp-dev para operaciones de aritmética de precisión arbitraria usadas en el algoritmo SHA-256. La imagen base haskell:9.6.3 no la incluye por defecto, causando error de linking en tiempo de compilación dentro del contenedor Docker."),
      h3("Solución"),
      p("Se añadió en el Dockerfile de HERMES la instalación explícita de libgmp-dev y libssl-dev antes de ejecutar cabal build. Alternativamente, se puede usar la imagen haskell:9.6.3-slim que incluye estas dependencias, pero la imagen estándar es más estable para builds reproducibles."),
      spacer(),

      new Paragraph({ children: [new PageBreak()] }),

      // ========================================================
      // 4. ESQUEMA DE BASE DE DATOS
      // ========================================================
      h1("4. Esquema de Base de Datos MySQL"),
      spacer(),
      p("El esquema refleja las cinco entidades del sistema. Las relaciones garantizan integridad referencial y permiten reconstruir la trazabilidad completa de cualquier transmisión."),
      spacer(),

      makeTable(
        ["Tabla", "Entidad del sistema", "Campos clave", "Relacionada con"],
        [
          ["misiones", "Misión espacial activa", "mission_id (PK), agencia, estado", "—"],
          ["sondas", "Estado de la sonda", "mission_id (FK), estado_sensores, distancia_km", "misiones"],
          ["anomalias", "Anomalía detectada", "anomalia_id (PK), clasificacion, confianza, cadena_reglas (JSON)", "misiones"],
          ["transmisiones", "Cadena de trazabilidad", "hash_sha256, trazabilidad, timestamp por nodo", "anomalias"],
          ["resumenes", "Resumen en pantalla", "contenido (JSON), nivel_alerta", "misiones"],
        ],
        [1600, 1800, 2400, 2200]
      ),
      spacer(),

      h2("4.1 Consulta de trazabilidad completa"),
      p("La siguiente consulta reconstruye el recorrido completo de una transmisión desde Voyager IX hasta GROUND:"),
      spacer(),
      code("SELECT m.mission_id, m.agencia, a.anomalia_id,"),
      code("       a.clasificacion, a.confianza,"),
      code("       t.hash_sha256, t.trazabilidad,"),
      code("       t.timestamp_relay, t.timestamp_atlas, t.timestamp_ground"),
      code("FROM   misiones m"),
      code("JOIN   anomalias a ON a.mission_id = m.mission_id"),
      code("JOIN   transmisiones t ON t.anomalia_id = a.anomalia_id"),
      code("WHERE  m.mission_id = 'VOYAGER-IX-2041'"),
      code("ORDER  BY t.timestamp_ground DESC;"),
      spacer(),

      new Paragraph({ children: [new PageBreak()] }),

      // ========================================================
      // 5. INSTRUCCIONES DE EJECUCIÓN
      // ========================================================
      h1("5. Instrucciones de Ejecución"),
      spacer(),

      h2("Requisitos"),
      bullet("Docker Desktop o Docker Engine + Docker Compose v2"),
      bullet("Puertos libres: 3306, 8001, 8002, 8003, 8004"),
      bullet("Conexión a internet para descargar imágenes base"),
      spacer(),

      h2("Levantar el sistema completo"),
      code("# Clonar / descomprimir el proyecto"),
      code("cd kepler/"),
      code(""),
      code("# Construir todas las imágenes y levantar"),
      code("docker compose up --build"),
      code(""),
      code("# El cliente Julia ejecuta el flujo automáticamente"),
      code("# Para ver solo los logs de Julia:"),
      code("docker compose logs -f julia"),
      spacer(),

      h2("Verificar salud de cada nodo"),
      code("curl http://localhost:8001/health   # Voyager IX (Prolog)"),
      code("curl http://localhost:8002/health   # HERMES (Haskell)"),
      code("curl http://localhost:8003/health   # ATLAS (Java)"),
      code("curl http://localhost:8004/health   # GROUND (Python)"),
      spacer(),

      h2("Disparar flujo directo manualmente"),
      code("# Paso 1: Voyager IX analiza la anomalía"),
      code("curl -X POST http://localhost:8001/analizar \\"),
      code("     -H 'Content-Type: application/json' \\"),
      code("     -d '{}'"),
      code(""),
      code("# Paso 2: HERMES recibe y reenvía a ATLAS"),
      code("curl -X POST http://localhost:8002/relay \\"),
      code("     -H 'Content-Type: application/json' \\"),
      code("     -d '<payload del paso anterior>'"),
      spacer(),

      h2("Flujo inverso y consulta de historial"),
      code("# Iniciar flujo inverso desde GROUND"),
      code("curl http://localhost:8004/consultar?mision=VOYAGER-IX-2041"),
      code(""),
      code("# Ver historial persistido en MySQL"),
      code("curl http://localhost:8004/historial/VOYAGER-IX-2041"),
      code(""),
      code("# Ver resúmenes en pantalla del Centro de Control"),
      code("curl http://localhost:8004/resumenes"),
      spacer(),

      h2("Consulta directa a MySQL"),
      code("docker exec -it kepler_mysql mysql -u kepler -pkeplerpass kepler_db"),
      code(""),
      code("mysql> SELECT * FROM resumenes ORDER BY generado_en DESC LIMIT 5;"),
      code("mysql> SELECT * FROM transmisiones;"),
      code("mysql> SELECT * FROM anomalias;"),
      spacer(),

      new Paragraph({ children: [new PageBreak()] }),

      // ========================================================
      // 6. RESUMEN DE PARADIGMAS
      // ========================================================
      h1("6. Resumen: Paradigmas Aplicados"),
      spacer(),
      p("Cada lenguaje del sistema fue elegido porque su paradigma dominante es la forma más natural de expresar el problema que ese nodo resuelve:"),
      spacer(),

      makeTable(
        ["Paradigma", "Lenguaje", "Cómo se manifiesta en el proyecto"],
        [
          ["Lógico / Declarativo", "Prolog", "Reglas de clasificación como cláusulas Horn; inferencia por backtracking automático; la cadena de reglas es la traza de ejecución"],
          ["Funcional Puro", "Haskell", "computeHash, verifyIntegrity, buildHermesPackage son funciones puras verificadas por el compilador; IO confinado al borde"],
          ["Orientado a Objetos", "Java", "Entidades modeladas como objetos; encapsulamiento de lógica de enriquecimiento; Spring Boot gestiona concurrencia y ciclo de vida"],
          ["Relacional", "MySQL", "Esquema normalizado con 5 entidades; integridad referencial via FK; consultas SQL reconstruyen trazabilidad completa"],
          ["Científico / Numérico", "Julia", "GROUND usa MySQL.jl para persistencia; el cliente realiza Stefan-Boltzmann, índice de habitabilidad y análisis espectral como ciudadanos de primera clase"],
        ],
        [2200, 1600, 4200]
      ),
      spacer(), spacer(),

      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 480 },
        children: [new TextRun({ text: "— Fin del informe —", size: 20, color: "AAAAAA", italics: true, font: "Arial" })]
      }),
    ]
  }]
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync("/mnt/user-data/outputs/informe_proyecto_kepler.docx", buf);
  console.log("Informe generado.");
});
