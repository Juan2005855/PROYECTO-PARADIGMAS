# JULIA CLIENT — Orquestador Automatico
# Paradigmas del Lenguaje 2026-01

using HTTP
using JSON3
using Dates
using Statistics
using Random

const VOYAGER_URL = get(ENV, "VOYAGER_URL", "http://voyager:8001")
const HERMES_URL  = get(ENV, "HERMES_URL",  "http://hermes:8002")
const ATLAS_URL   = get(ENV, "ATLAS_URL",   "http://atlas:8003")
const GROUND_URL  = get(ENV, "GROUND_URL",  "http://ground:8004")

log_sec(t)  = println("\n" * "="^58 * "\n  $t\n" * "="^58)
log_ok(m)   = println("  OK: $m")
log_info(m) = println("  -> $m")
log_err(m)  = println("  ERR: $m")

# Analisis espectral Julia
function analisis_espectral(albedo, temp_k)
    log_sec("ANALISIS ESPECTRAL Julia")
    L = 3.828e26; d = 1.194*1.496e11; s = 5.67e-8
    T = ((L*(1-albedo))/(16*pi*d^2*s))^0.25
    hab = exp(-((temp_k-323.15)^2)/(2*50^2))
    log_info("Albedo: $albedo")
    log_info("T efectiva: $(round(T,digits=2)) K")
    log_info("Hab score: $(round(hab,digits=4))")
    hab > 0.5 && log_ok("ZONA HABITABLE")
    return Dict("T_efectiva"=>round(T,digits=2), "hab_score"=>round(hab,digits=4))
end

# Verificar nodos
function verificar_nodos()
    log_sec("VERIFICACION DE SALUD")
    for (n,u) in [("Voyager (Prolog)","$VOYAGER_URL/health"),
                  ("HERMES (Haskell)","$HERMES_URL/health"),
                  ("ATLAS (Java)",    "$ATLAS_URL/health"),
                  ("GROUND (Julia)",  "$GROUND_URL/health")]
        try
            r = HTTP.get(u; connect_timeout=5, readtimeout=5)
            d = JSON3.read(r.body)
            log_ok("$n — $(d.status)")
        catch
            log_err("$n — no responde")
        end
    end
end

# Un flujo con datos aleatorios
function ejecutar_flujo()
    log_sec("FLUJO AUTOMATICO")

    # Voyager genera anomalia aleatoria
    log_info("Voyager IX genera observacion aleatoria...")
    resp_v = HTTP.post("$VOYAGER_URL/analizar",
                       ["Content-Type"=>"application/json"], "{}")

    # Prolog puede incluir logs antes del JSON — extraer solo el JSON
    body_str = String(resp_v.body)
    json_start = findfirst('{', body_str)
    # Extraer solo el JSON puro (Prolog puede incluir logs antes del {)
    json_str = json_start !== nothing ? body_str[json_start:end] : body_str
    # Asegurarse de que termina en } (eliminar cualquier texto después del JSON)
    json_end = findlast('}', json_str)
    json_str = json_end !== nothing ? json_str[1:json_end] : json_str
    r = JSON3.read(json_str)

    log_ok("Voyager respondio:")
    log_info("  Anomalia:      $(r.anomalia_id)")
    log_info("  Clasificacion: $(r.clasificacion)")
    log_info("  Confianza:     $(r.confianza)")
    log_info("  RA/Dec:        $(r.coordenadas.ascension_recta) / $(r.coordenadas.declinacion)")
    log_info("  Espectral:     $(r.lectura_espectral.codigo)")
    reglas = join(r.cadena_reglas, ", ")
    log_info("  Reglas:        $reglas")

    confianza_real = Float64(r.confianza)
    escenario = rand(1:3)

    if escenario == 1
        # CASO: confianza baja -> HERMES rechaza
        log_sec("CASO: Confianza baja -> HERMES RECHAZA")
        conf_baja = round(rand() * 0.45, digits=2)
        log_info("Enviando confianza baja: $conf_baja")
        payload = Dict(
            "mission_id"    => string(r.mission_id),
            "anomalia_id"   => string(r.anomalia_id) * "-LOW",
            "clasificacion" => string(r.clasificacion),
            "confianza"     => conf_baja,
            "timestamp_utc" => string(r.timestamp_utc),
            "origen"        => "VOYAGER_IX",
            "cadena_reglas" => collect(r.cadena_reglas)
        )
        resp_h = try
            HTTP.post("$HERMES_URL/relay",
                      ["Content-Type"=>"application/json"],
                      JSON3.write(payload))
        catch e; e.response end
        hd = JSON3.read(resp_h.body)
        log_ok("HERMES rechazo correctamente:")
        log_info("  Estado:    $(hd.estado)")
        log_info("  Motivo:    $(hd.motivo)")
        log_info("  Confianza: $conf_baja < $(hd.minimo)")
        log_info("  Accion:    $(hd.accion)")
        return "RECHAZADO_CONFIANZA_BAJA"

    elseif escenario == 2
        # CASO: SHA corrupto -> HERMES rechaza
        log_sec("CASO: SHA-256 alterado -> HERMES RECHAZA")
        payload = Dict(
            "mission_id"    => string(r.mission_id),
            "anomalia_id"   => string(r.anomalia_id) * "-CORRUPT",
            "clasificacion" => string(r.clasificacion),
            "confianza"     => confianza_real,
            "timestamp_utc" => string(r.timestamp_utc),
            "origen"        => "VOYAGER_IX",
            "cadena_reglas" => collect(r.cadena_reglas)
        )
        resp_h = try
            HTTP.post("$HERMES_URL/relay-corrupto",
                      ["Content-Type"=>"application/json"],
                      JSON3.write(payload))
        catch e; e.response end
        hd = JSON3.read(resp_h.body)
        log_ok("HERMES detecto corrupcion:")
        log_info("  Estado: $(hd.estado)")
        log_info("  Motivo: $(hd.motivo)")
        log_info("  Accion: $(hd.accion)")
        return "RECHAZADO_SHA_CORRUPTO"

    else
        # CASO: flujo completo exitoso
        log_sec("CASO: Confianza OK ($confianza_real) -> FLUJO COMPLETO")
        log_info("Voyager ya envio automaticamente a HERMES...")
        sleep(3)
        resp_g = HTTP.get("$GROUND_URL/resumenes")
        gd = JSON3.read(resp_g.body)
        if !isempty(gd.resumenes)
            u = gd.resumenes[1]
            log_ok("MySQL confirma persistencia:")
            nivel = parse(Int, string(u.nivel_alerta))
            log_info("  Nivel alerta: $nivel")
            nivel >= 10 && log_ok("ALERTA MAXIMA — POSIBLE ESTRUCTURA ARTIFICIAL")
        end
        analisis_espectral(0.34, 284.0)
        return "FLUJO_COMPLETO_OK"
    end
end


# Flujo manual con datos del usuario
function ejecutar_manual(datos::Dict)
    log_sec("FLUJO MANUAL")

    log_info("Enviando datos manuales a Voyager IX...")
    resp_v = HTTP.post("$VOYAGER_URL/analizar-manual",
                       ["Content-Type"=>"application/json"],
                       JSON3.write(datos))

    body_str = String(resp_v.body)
    json_start = findfirst('{', body_str)
    json_end   = findlast('}', body_str)
    json_str   = body_str[json_start:json_end]
    r = JSON3.read(json_str)

    log_ok("Voyager clasifico los datos:")
    log_info("  Anomalia:      $(r.anomalia_id)")
    log_info("  Modo:          MANUAL")
    log_info("  Clasificacion: $(r.clasificacion)")
    log_info("  Confianza:     $(r.confianza)")
    reglas = join(r.cadena_reglas, ", ")
    log_info("  Reglas:        $reglas")

    sleep(2)
    resp_g = HTTP.get("$GROUND_URL/resumenes")
    gd = JSON3.read(resp_g.body)
    if !isempty(gd.resumenes)
        u = gd.resumenes[1]
        nivel = parse(Int, string(u.nivel_alerta))
        log_ok("MySQL confirma persistencia — nivel alerta: $nivel")
        nivel >= 10 && log_ok("ALERTA MAXIMA — POSIBLE ESTRUCTURA ARTIFICIAL")
    end

    return Dict("clasificacion"=>string(r.clasificacion),
                "confianza"=>Float64(r.confianza),
                "anomalia_id"=>string(r.anomalia_id),
                "cadena_reglas"=>collect(r.cadena_reglas))
end

# Flujo inverso
function flujo_inverso()
    log_sec("FLUJO INVERSO: GROUND->ATLAS->HERMES->Voyager")
    try
        resp = HTTP.get("$GROUND_URL/consultar?mision=VOYAGER-IX-2041";
                        readtimeout=10)
        d = JSON3.read(resp.body)
        log_ok("Consulta inversa OK")
        traz = get(d, :trazabilidad, "N/A")
        log_info("Trazabilidad: $traz")
        datos = get(d, :datos, nothing)
        if datos !== nothing && haskey(datos, :historial)
            for ev in datos.historial
                log_info("[$(ev.fecha)] $(ev.evento)")
            end
        end
    catch e
        log_err("Flujo inverso: $e")
    end
end

# Router HTTP
function router(req::HTTP.Request)
    path   = HTTP.URI(req.target).path
    method = req.method
    try
        if method == "GET" && path == "/health"
            return HTTP.Response(200, ["Content-Type"=>"application/json"],
                JSON3.write(Dict("status"=>"ok","nodo"=>"JULIA_CLIENT")))

        elseif method == "POST" && path == "/ejecutar"
            resultado = ejecutar_flujo()
            return HTTP.Response(200, ["Content-Type"=>"application/json"],
                JSON3.write(Dict("caso"=>resultado,"ok"=>true)))

        elseif method == "POST" && path == "/ejecutar-multiple"
            params = HTTP.queryparams(HTTP.URI(req.target))
            n = parse(Int, get(params, "n", "3"))
            casos = String[]
            for i in 1:n
                println("\n[Ejecucion $i/$n]")
                try
                    push!(casos, ejecutar_flujo())
                catch e
                    push!(casos, "ERROR: $e")
                end
                i < n && sleep(1)
            end
            flujo_inverso()
            return HTTP.Response(200, ["Content-Type"=>"application/json"],
                JSON3.write(Dict("ejecuciones"=>casos,"total"=>n)))

        elseif method == "POST" && path == "/ejecutar-manual"
            body_str = String(req.body)
            datos = JSON3.read(body_str, Dict{String,String})
            resultado = ejecutar_manual(Dict(string(k)=>string(v) for (k,v) in datos))
            return HTTP.Response(200, ["Content-Type"=>"application/json"],
                JSON3.write(merge(resultado, Dict("ok"=>true))))

        elseif method == "GET" && path == "/inverso"
            flujo_inverso()
            return HTTP.Response(200, ["Content-Type"=>"application/json"],
                JSON3.write(Dict("ok"=>true)))

        elseif method == "GET" && path == "/nodos"
            verificar_nodos()
            return HTTP.Response(200, ["Content-Type"=>"application/json"],
                JSON3.write(Dict("ok"=>true)))

        else
            return HTTP.Response(200, ["Content-Type"=>"application/json"],
                JSON3.write(Dict(
                    "rutas"=>[
                        "POST /ejecutar             — 1 flujo aleatorio",
                        "POST /ejecutar-manual      — datos manuales",
                        "POST /ejecutar-multiple?n=5 — N flujos aleatorios",
                        "GET  /inverso              — flujo inverso",
                        "GET  /nodos                — salud de nodos",
                        "GET  /health               — estado cliente"
                    ])))
        end
    catch e
        println("[JULIA] Error router: $e")
        return HTTP.Response(500, ["Content-Type"=>"application/json"],
            JSON3.write(Dict("error"=>string(e))))
    end
end

# MAIN
function main()
    println("\n" * "#"^60)
    println("  PROYECTO KEPLER — Cliente Julia")
    println("  Datos dinamicos aleatorios | Puerto 8005")
    println("#"^60)

    sleep(4)
    println("\nEsperando servicios...")
    for i in 1:8
        try
            HTTP.get("$VOYAGER_URL/health"; connect_timeout=3, readtimeout=3)
            HTTP.get("$GROUND_URL/health";  connect_timeout=3, readtimeout=3)
            println("[JULIA] Servicios listos")
            break
        catch
            println("[JULIA] Intento $i/8...")
            sleep(4)
        end
    end

    verificar_nodos()

    println("\n[JULIA] Ejecutando flujo inicial...")
    try
        ejecutar_flujo()
    catch e
        log_err("$e")
    end
    try
        flujo_inverso()
    catch e
        log_err("$e")
    end

    println("\n[JULIA] Servidor activo en puerto 8005")
    println("[JULIA] POST http://localhost:8005/ejecutar       — datos aleatorios")
    println("[JULIA] POST http://localhost:8005/ejecutar-multiple?n=5 — 5 ejecuciones\n")

    HTTP.serve(router, "0.0.0.0", 8005)
end

main()