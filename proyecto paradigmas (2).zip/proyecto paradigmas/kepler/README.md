# Proyecto Kepler — La última transmisión de Voyager IX
## Paradigmas del Lenguaje 2026-01

---

## Arquitectura del Sistema

```
[Julia Cliente]
      |
      v  (orquesta el flujo completo)
      |
[Voyager IX]  --HTTP-->  [HERMES]  --HTTP-->  [ATLAS]  --HTTP-->  [GROUND]
  Prolog:8001              Haskell:8002        Java:8003           Python:8004
  Sistema experto          Relay SHA-256       Coordinación        ↓
  Base de reglas           Funciones puras     Trazabilidad      [MySQL:3306]
  Inferencia               Integridad          140 misiones       Persistencia
```

### Flujo directo (izquierda → derecha):
1. **Julia** solicita análisis a Voyager IX
2. **Voyager IX** (Prolog) clasifica la anomalía con su base de reglas
3. **HERMES** (Haskell) verifica SHA-256 y reenvía canónicamente
4. **ATLAS** (Java) enriquece con trazabilidad y despacha a GROUND
5. **GROUND** persiste en MySQL y genera resumen para pantalla

### Flujo inverso (derecha → izquierda):
`GROUND /consultar` → `ATLAS /consultar` → `HERMES /consultar` → `VOYAGER /historial`

---

## Ejecución

```bash
# Levantar todo el sistema
docker compose up --build

# El cliente Julia ejecuta automáticamente el flujo completo
docker compose logs -f julia
```

## Verificar salud de cada nodo

```bash
curl http://localhost:8001/health   # Voyager IX (Prolog)
curl http://localhost:8002/health   # HERMES (Haskell)
curl http://localhost:8003/health   # ATLAS (Java)
curl http://localhost:8004/health   # GROUND (Python)
```

## Flujo manual paso a paso

```bash
# 1. Voyager IX clasifica anomalía
curl -X POST http://localhost:8001/analizar \
     -H 'Content-Type: application/json' -d '{}'

# 2. HERMES verifica y reenvía (pegar respuesta del paso anterior)
curl -X POST http://localhost:8002/relay \
     -H 'Content-Type: application/json' \
     -d '<respuesta de voyager>'

# 3. Ver estado en ATLAS
curl http://localhost:8003/estado

# 4. Ver resúmenes en GROUND
curl http://localhost:8004/resumenes

# 5. Ver historial completo
curl http://localhost:8004/historial/VOYAGER-IX-2041
```

## Consulta directa a MySQL

```bash
docker exec -it kepler_mysql mysql -u kepler -pkeplerpass kepler_db

# En MySQL:
SELECT * FROM resumenes ORDER BY generado_en DESC LIMIT 5;
SELECT * FROM transmisiones;
SELECT a.anomalia_id, a.clasificacion, a.confianza, t.hash_sha256, t.trazabilidad
FROM anomalias a JOIN transmisiones t ON t.anomalia_id = a.anomalia_id;
```

---

## Mapeo Lenguaje → Paradigma → Nodo

| Lenguaje | Paradigma | Nodo | Justificación |
|----------|-----------|------|---------------|
| Prolog | Lógico/Declarativo | Voyager IX | Base de reglas + inferencia por backtracking |
| Haskell | Funcional puro | HERMES | Pureza garantizada por el compilador (no solo convención) |
| Java | OOP | ATLAS | Interoperabilidad enterprise, concurrencia, ecosistema maduro |
| MySQL | Relacional | GROUND | Persistencia estructurada con integridad referencial |
| Julia | Científico/Numérico | Cliente | Análisis espectral, Stefan-Boltzmann, índice habitabilidad |
